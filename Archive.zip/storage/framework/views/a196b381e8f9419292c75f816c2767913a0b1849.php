<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>

<img src="https://live.staticflickr.com/65535/52422520992_71aeb7398b_o.png" style="width:314px !important;height:59px !important" class="logo" alt="中央情報専門学校">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH /Users/takumi/Desktop/present/present/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/header.blade.php ENDPATH**/ ?>